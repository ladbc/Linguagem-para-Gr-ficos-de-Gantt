package br.ufscar.dc.compiladores.lasemantico;

public class AnaliseSemantica extends LASemanticoBaseVisitor<Void> {
    
}
